# Real Estate AI Toolkit - Starter Pack

This archive contains starter artifacts to kick off an AI-driven real-estate deals product:
- Canonical property data schema + sample payload (schema/property_schema.md)
- React + Tailwind prototype (frontend/)
- FastAPI backend skeleton (backend/)
- ML model pipeline starter (ml/)
- Data-licensing checklist & template emails (legal/)

Unzip and follow each component README for run instructions.
