# Backend Skeleton

## Setup
1. `pip install -r requirements.txt`
2. `uvicorn main:app --reload --port 8000`
3. Endpoints:
   - `GET /api/properties` — list properties
   - `POST /api/properties` — add a property (JSON)
   - `GET /api/properties/{id}` — fetch one property by id

CORS is enabled to allow frontend running on a different port.
