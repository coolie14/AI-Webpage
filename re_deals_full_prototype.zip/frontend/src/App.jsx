import React, { useState, useEffect } from 'react'
import Map from './components/Map'
import sample from './data/sample_properties.json'

export default function App(){
  const [properties] = useState(sample)
  const [selected, setSelected] = useState(null)

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <header className="p-6 bg-gradient-to-r from-indigo-600 to-blue-500 text-white">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-semibold">RE Deals — Prototype</h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 grid grid-cols-3 gap-6">
        <section className="col-span-1 space-y-4">
          <div className="bg-white p-4 rounded shadow">
            <h2 className="font-semibold">Filters</h2>
            <p className="text-sm text-gray-500">Basic filters (mock)</p>
          </div>

          <div className="bg-white p-4 rounded shadow overflow-auto max-h-[60vh]">
            {properties.map(p => (
              <div key={p.id} className="p-3 border-b hover:bg-gray-50 cursor-pointer" onClick={()=>setSelected(p)}>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium">{p.address.street}</div>
                    <div className="text-xs text-gray-500">{p.address.city}, {p.address.state}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold">${p.price.toLocaleString()}</div>
                    <div className="text-sm text-gray-500">Score: {p.score.deal_score}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="col-span-2">
          <div className="bg-white rounded shadow p-4 h-[70vh]">
            <Map properties={properties} onSelect={setSelected} mapboxToken={import.meta.env.VITE_MAPBOX_TOKEN || ''} />
          </div>
          {selected && (
            <div className="mt-4 bg-white p-4 rounded shadow">
              <h3 className="font-bold">{selected.address.street} — ${selected.price.toLocaleString()}</h3>
              <p className="text-sm text-gray-600">Deal score: {selected.score.deal_score}</p>
            </div>
          )}
        </section>
      </main>
    </div>
  )
}
