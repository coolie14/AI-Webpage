import React, { useEffect, useRef } from 'react'
import mapboxgl from 'mapbox-gl'

export default function Map({ properties, onSelect, mapboxToken }){
  const mapNode = useRef(null)
  const mapRef = useRef(null)

  useEffect(()=>{
    if(!mapNode.current) return
    mapboxgl.accessToken = mapboxToken || ''
    mapRef.current = new mapboxgl.Map({
      container: mapNode.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [-77.0369, 38.9072],
      zoom: 10
    })

    properties.forEach(p=>{
      const el = document.createElement('div')
      el.className = 'marker'
      el.style.background = '#2563eb'
      el.style.width = '12px'
      el.style.height = '12px'
      el.style.borderRadius = '50%'
      el.style.cursor = 'pointer'
      const marker = new mapboxgl.Marker(el)
        .setLngLat([p.geo.lng, p.geo.lat])
        .addTo(mapRef.current)

      el.addEventListener('click', ()=> onSelect(p))
    })

    return ()=> mapRef.current.remove()
  }, [properties])

  return <div ref={mapNode} style={{width:'100%', height:'100%'}} />
}
