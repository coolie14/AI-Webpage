# Data Licensing Checklist - Real Estate Product

This checklist helps ensure lawful use of third-party property data.

1. Identify data sources
   - MLS (which MLS?), Zillow API, County assessor, CoreLogic, ATTOM, Redfin (note: Redfin often restricts scraping)
2. Review Terms of Service & API docs for each source
   - Do not scrape if explicitly prohibited
3. Check commercial usage rights
   - Free vs paid tiers, attribution requirements, rate limits
4. Negotiate/obtain licensing agreements where necessary
   - MLS broker agreements, data licensing contracts
5. Plan for data refresh & compliance
   - Adhere to rate limits, caching rules, and attribution
6. Document provenance for each record (source, retrieved_at, confidence)
7. Consider user privacy & PII
   - Avoid storing sensitive personal data; publish privacy policy
8. Legal review
   - Engage counsel before launching large-scale ingestion or monetization

