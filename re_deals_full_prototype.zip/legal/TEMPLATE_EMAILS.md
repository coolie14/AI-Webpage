# Template outreach emails

## A) MLS / Broker Partnership (initial outreach)
Subject: Partnership inquiry — data access for real-estate analytics product

Hello [Name],

I'm building an AI-driven real-estate deals platform that surfaces high-value listings for buyers and investors. We are seeking licensed access to MLS feeds and would like to explore partnership/licensing options with [MLS/Broker Name].

Key points:
- Use case: analytics, scored listing surfacing, lead referrals to local agents
- Initial pilot geography: [City/County]
- Data needs: listing feed (property details, photos, price history, status), updates (near real-time)
- We are open to commercial terms and attorney-reviewed contracts

Could we schedule a 30-minute call to discuss feasibility and next steps?

Best regards,
[Your Name]
[Your Title]
[Contact Info]

## B) Zillow API / Data Access (polite query)
Subject: Data access commercial use inquiry

Hello Zillow Developer Relations team,

I am evaluating Zillow's APIs for a pilot of an AI-driven property deals application. Could you advise on commercial licensing options, API limits, and any restrictions on using Zestimate and listing data for a product that surfaces investment opportunities?

Thanks,
[Your Name]

## C) County Assessor (public records request)
Subject: Request for property tax & assessment data access

Hello [County Office],

We are developing a property analytics tool and would like to obtain bulk assessor/tax data for [County, State] for non-commercial research/pilot purposes (or commercial if applicable). Please advise on formats, fees, and acceptable use policies.

Thank you,
[Your Name]
[Contact Info]
