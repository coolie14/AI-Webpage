# ML Pipeline Starter - Overview

This folder contains a starter script to train a simple comps-based value model and produce a predicted market value.
The goal: train a regression model that predicts sale price from features (sqft, beds, baths, year_built, lat/lng features, neighborhood indicators).

Files:
- train.py : starter training script using scikit-learn
- sample_data.csv : small synthetic dataset for local testing
- notebook_instructions.md : steps to turn train.py into a notebook
