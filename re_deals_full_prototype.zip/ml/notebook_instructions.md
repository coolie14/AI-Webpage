# Notebook Instructions

To convert `train.py` into a notebook:
1. Create a new notebook and copy the script into sequential cells.
2. Add markdown cells explaining dataset, features, evaluation metrics, and next steps.
3. Visualize residuals, feature importances (model.feature_importances_), and partial dependence plots.
