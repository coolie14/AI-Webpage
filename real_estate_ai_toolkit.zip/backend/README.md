# Backend Skeleton (FastAPI)

## Run locally
1. Create virtual env and install: `pip install -r requirements.txt`
2. Start server: `uvicorn main:app --reload --port 8000`
3. POST a property to `/api/properties` (JSON) or GET `/api/properties`

This skeleton uses an in-memory list and a simple rule-based scorer. Swap in a DB in production.
