from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import uuid4
from datetime import datetime

app = FastAPI(title="RE Deals API - Skeleton")

# Pydantic models
class Address(BaseModel):
    street: str
    city: str
    state: str
    zip: Optional[str] = None
    country: Optional[str] = "US"

class Score(BaseModel):
    deal_score: float
    components: Optional[dict] = {}
    generated_at: Optional[datetime] = None

class Property(BaseModel):
    id: str
    source: str
    source_id: Optional[str] = None
    status: Optional[str] = "active"
    property_type: Optional[str] = "house"
    address: Address
    geo: dict
    price: float
    beds: Optional[int] = None
    baths: Optional[float] = None
    sqft: Optional[int] = None
    score: Optional[Score] = None

# In-memory store (replace with DB)
PROPERTIES = []

# Simple dummy scorer
def compute_deal_score(prop: dict) -> dict:
    # rule-based: cheaper relative to zestimate and higher rent_estimate -> better
    base = 50.0
    price = prop.get('price') or 0
    z = prop.get('zestimate') or price
    gap = max((z - price) / max(z,1) * 100, -50)  # percent
    rent = prop.get('rent_estimate') or 0
    cap = (rent*12) / max(price,1) * 100 if price>0 else 0
    score = base + gap*0.4 + cap*0.6
    score = max(0, min(100, score))
    return {
        "deal_score": round(score,1),
        "components": {"value_gap_pct": round(gap,2), "cap_rate_pct": round(cap,2)},
        "generated_at": datetime.utcnow().isoformat() + "Z"
    }

@app.post("/api/properties", response_model=Property)
def create_property(prop: Property):
    # compute score and store
    prop_dict = prop.dict()
    prop_dict['id'] = prop_dict.get('id') or str(uuid4())
    prop_dict['score'] = compute_deal_score(prop_dict)
    PROPERTIES.append(prop_dict)
    return prop_dict

@app.get("/api/properties", response_model=List[Property])
def list_properties(sort: Optional[str] = None):
    if sort == 'deal_score':
        return sorted(PROPERTIES, key=lambda p: p.get('score',{}).get('deal_score',0), reverse=True)
    return PROPERTIES

@app.get("/api/properties/{property_id}", response_model=Property)
def get_property(property_id: str):
    for p in PROPERTIES:
        if p['id'] == property_id or p.get('source_id') == property_id:
            return p
    raise HTTPException(status_code=404, detail="Property not found")
