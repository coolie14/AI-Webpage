# Frontend Prototype (React + Tailwind)

## Setup
1. Install dependencies: `npm install`
2. Create `.env` at project root with `VITE_MAPBOX_TOKEN=your_token_here`
3. Run dev server: `npm run dev`

This is a UI-only prototype that consumes `src/data/sample_properties.json`.
