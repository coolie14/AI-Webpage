# Canonical Property Data Schema

This document defines the canonical property schema used across the system and includes sample JSON payloads.

## Core fields (recommended)
- `id` (string): canonical unique id for the property (UUID or source:id)
- `source` (string): source system (e.g., "zillow", "mls", "county")
- `source_id` (string): id in the source system
- `status` (string): listing status ("active", "pending", "sold", "off-market")
- `property_type` (string): one of ["house","townhome","multi-family","condo","co-op","lot","land","manufactured","apartment"]
- `address` (object):
  - `street`, `city`, `state`, `zip`, `country`
- `geo` (object): `{ "lat": float, "lng": float }`
- `price` (number): listing price in USD
- `price_history` (array): [{ "date": "YYYY-MM-DD", "price": number, "event": "listed|sold|price_change" }]
- `beds` (int), `baths` (float), `sqft` (int)
- `lot_sqft` (int), `year_built` (int)
- `images` (array of URLs)
- `description` (string)
- `days_on_market` (int)
- `tax_assessment` (object): `{ "year": int, "assessed_value": number }`
- `zestimate` (number, optional)
- `rent_estimate` (number, optional)
- `estimated_repair_cost` (number, optional)
- `score` (object):
  - `deal_score` (0-100), `components` (map of factor->value), `generated_at` (timestamp)
- `comps` (array): nearby comparable sales with price, date, distance
- `amenities` (array): e.g., ["garage","pool","central_ac"]
- `neighborhood` (object): `{ "walk_score": int, "school_rating": float, "crime_index": float }`
- `metadata` (object): freeform for ingestion notes, source confidence

## Example JSON payload
```json
{
  "id": "uuid-1234",
  "source": "zillow",
  "source_id": "Z123456789",
  "status": "active",
  "property_type": "house",
  "address": {
    "street": "123 Maple Ave",
    "city": "Springfield",
    "state": "VA",
    "zip": "22150",
    "country": "US"
  },
  "geo": { "lat": 38.4245, "lng": -77.408 },
  "price": 395000,
  "price_history": [
    { "date": "2025-09-01", "price": 399000, "event": "listed" },
    { "date": "2025-09-10", "price": 395000, "event": "price_change" }
  ],
  "beds": 3,
  "baths": 2.5,
  "sqft": 1850,
  "lot_sqft": 7500,
  "year_built": 1998,
  "images": ["https://cdn.example.com/img1.jpg"],
  "description": "Well-maintained 3BR home near downtown.",
  "days_on_market": 12,
  "tax_assessment": { "year": 2024, "assessed_value": 360000 },
  "zestimate": 385000,
  "rent_estimate": 2200,
  "estimated_repair_cost": 12000,
  "score": {
    "deal_score": 84,
    "components": {
      "value_gap_pct": 3.5,
      "cap_rate_est": 7.8,
      "renovation_risk": -4.0
    },
    "generated_at": "2025-10-17T12:00:00Z"
  },
  "comps": [
    { "id": "comp-1", "price": 420000, "date": "2025-06-12", "distance_miles": 0.6 }
  ],
  "amenities": ["garage","fenced_yard"],
  "neighborhood": { "walk_score": 62, "school_rating": 7.4, "crime_index": 28 },
  "metadata": { "ingest_notes": "Zillow API v2, confidence: 0.87" }
}
```

